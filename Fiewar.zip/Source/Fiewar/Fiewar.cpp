// Copyright Epic Games, Inc. All Rights Reserved.

#include "Fiewar.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Fiewar, "Fiewar" );
 