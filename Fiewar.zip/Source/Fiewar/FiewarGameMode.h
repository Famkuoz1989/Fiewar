// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "FiewarGameMode.generated.h"

UCLASS(minimalapi)
class AFiewarGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AFiewarGameMode();
};



